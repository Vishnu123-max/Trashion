<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");
//including the database connection file
$con = mysqli_connect("localhost","root","","projectpbl");
if (mysqli_connect_errno()){
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    die();
    }
//echo "test1";
if(isset($_POST["submit"])) {	
	//echo "test2";
	$name = $_POST['firstname'];
	$email = $_POST['email'];
	$add  = $_POST['address'];
    $phone = $_POST['phone'];
    $city =  $_POST['city'];
    $state = $_POST['state'];
    $zip =  $_POST['zip'];
    $sum = $_POST['sum'];
    //echo $sum;
	if(empty($name) || empty($email) || empty($add) || empty($phone) ) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		
		if(empty($add)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
		}
		if(empty($phone)) {
			echo "<font color='red'>Phone_no field is empty.</font><br/>";
		}
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
		//	#echo "test3";
		//insert data to database	
        $result = mysqli_query($con,"INSERT INTO purchases(name,email,address,phone,city,state,zip) VALUES('$name','$email','$add','$phone','$city','$state','$zip')");
        if($result){
            //echo "yes";
          }else{
            echo "The record was not inserted successfully---->" . mysqli_error($con);
          }
        }
		//echo "test 3";
		//display success message
	}
?>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<title>Check Out Page</title>
<style>
.styled-table {
    border-collapse: collapse;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 800px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    margin-left: auto;
    margin-right: auto;
}
.styled-table th{
    background-color: #009879;
    color: #ffffff;
    text-align: center;
}
.styled-table td {
    padding: 12px 15px;
    width: 30%;
}
.styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
    text-align: center;
}

.styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
}

.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
}
.styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
}
</style>
</head>
<body>
	<h1><center>Review your Details</center></h1>
    <form method="post" action="pgRedirect.php">
    <table class="styled-table">
    <tbody>
    <tr>
        <th>CUSTOMER NAME</th> 
        <td><?php echo $name ?>
		</td>
        </tr>
        <tr>
        <th>ADDRESS</th> 
        <td><?php echo $add ?>
		</td>
        </tr> 
        <tr>
        <th>PHONE</th> 
        <td><?php echo $phone ?>
		</td>
        </tr>  
        <tr>
        <th>ORDER ID</th> 
        <td><input id="ORDER_ID" maxlength="20" size="12"
						name="ORDER_ID" autocomplete="off"
						value="<?php echo  "ORDS" . rand(10000,99999999)?>">
		</td>
        </tr>
        <tr>
        <th>CUSTOMER ID</th>
		<td><input id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="CUST001"></td>
        </tr>
        <tr>
        <th>INDUSTRY TYPE ID</th>
		<td><input id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail"></td>  
        </tr>
        <tr>
			<th>CHANNEL</th>
			<td><input id="CHANNEL_ID" tabindex="4" maxlength="12"
						size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
					</td>
		</tr>
		<tr>
            <th>TOTAL AMOUNT</th>
            <td><input title="TXN_AMOUNT" tabindex="4" size="8"
            					type="text" name="TXN_AMOUNT"
						value="<?php echo $sum ?>">
					</td>
				</tr>
		<tr>
           <td></td>         
        <td><input value="Check Out" type="submit"	class = "btn btn-success" onclick=""></td>
				</tr>
    </tbody>
</table>
</form>
</body>
</html>