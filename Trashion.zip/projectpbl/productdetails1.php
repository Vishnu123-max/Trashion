<html>
<head>
<title>Product Details</title>
<link rel="stylesheet" href="style1.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>

<body>
<?php
//connecting to database 
$username = "root"; 
$password = ""; 
$database = "health1"; 
$mysqli = new mysqli("localhost", $username, $password, $database);


//$id = $_POST['Product_id'];
$id = ''; 
if( isset( $_POST["Product_id"])) {
    $id = $_POST["Product_id"]; 
} 
$sql = "SELECT * FROM product where Product_id = '$id'";
if ($result = $mysqli->query($sql)) {
    while($row = $result->fetch_assoc()){ 
        $field1name = $row["Name"];
        $field2name = $row["Cost"];
        $field3name = $row["Units"];
     
    //$result->free();
}
}
?>
    <div class="container">
        <div class="row>">
            <div class='col-md-5'>
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="./images/'.$row["Product_id"].'.jpg" class="d-block w-100" alt="Photo of '.$row["Name"].">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="same">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="same">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
            
            </div>
            <div class='col-md-7'>
                <p class = "newarrival text-center">NEW</p>
                <h2>'.$field1name.'</h2>
                <img src="star.png" class="stars">
                <p class ='price'> '.$field2name.'</p>
                <p><b>Availability:</b> In Stock</p>
                <label>Quantity:</label>
                <input type="number">
                <button type="button" class="btn btn-secondary">Add to Cart</button>

                
                
                

            
            </div>
        
        
        </div>
    
    
    </div>
    </body>
</html>