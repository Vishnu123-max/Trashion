<?php
echo '<div><h1 style="font-family:sans-serif;color:coral"><center><br><br><br>Login Successful<br>Go to <br><br><a style="color:white" href="index.html"><button class="button" ><span>
<i class="fa fa-home"></i>  Home</span></button></a></center></h1></div>';
?>