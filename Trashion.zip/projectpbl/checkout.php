<?php
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");
	$sum = 0;
	if( isset( $_POST["submit"])) {
		$sum = $_POST["sum"];
	}

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>

    function checkField1()
    {
        var a= /^[A-Z a-z]+$/;
      var field = document.getElementById("field2").value;
      var fieldpsw = document.getElementById("field2").value.replace(/^\s+/, '').replace(/\s+$/, '');
      if (fieldpsw === ''){
        document.getElementById("message2").innerHTML = "Name cannot be only whitespaces";
      }
      else if (field.match(a))
      {
        document.getElementById("message2").innerHTML = " ";
      }
      else
            document.getElementById("message2").innerHTML = "Input Empty or numbers or special characters used.";
        
    }
    
    function checkField2(){
        var a= /^[A-Za-z]+$/;
        var lname = document.getElementById("field3").value;
        if (lname.match(a))
      {
        document.getElementById("message3").innerHTML = " ";
      }
      else
            document.getElementById("message3").innerHTML = "Input Empty or numbers or special characters used.";
    }
    function checkField21(){
        var a= /^[A-Za-z]+$/;
        var lname = document.getElementById("field21").value;
        if (lname.match(a))
      {
        document.getElementById("message31").innerHTML = " ";
      }
      else
            document.getElementById("message31").innerHTML = "Input Empty or numbers or special characters used.";
    }
    function checkField22(){
        var a= /^[A-Za-z]+$/;
        var lname = document.getElementById("field22").value;
        if (lname.match(a))
      {
        document.getElementById("message32").innerHTML = " ";
      }
      else
            document.getElementById("message32").innerHTML = "Input Empty or numbers or special characters used.";
    }
    function checkField3()
    {
      var field = document.getElementById("password").value;
      var fieldpsw = document.getElementById("password").value.replace(/^\s+/, '').replace(/\s+$/, '');
      var pattern= /^[^\s]+(\s+[^\s]+)*$/;
      if (fieldpsw === ''){
        document.getElementById("message5").innerHTML = "Password cannot be only whitespaces";
      } 
      else if(field.match(pattern)) {
        document.getElementById("message5").innerHTML = " ";
        if (field.length < 5)
      {
        document.getElementById("message5").innerHTML = "Too short!";
      }
      else
        document.getElementById("message5").innerHTML = "That's perfectly splendid!";
    }
    else{
      document.getElementById("message5").innerHTML = "Password cannot begin or end with a whitespace";
    }
        }
      
    function confirmpassword(){
        pass1= document.getElementById("password").value;
        pass2= document.getElementById("password_confirm").value;
        if(pass1 != pass2)
        {
            document.getElementById("message4").innerHTML = "Password does not match";
        }
        else{
          document.getElementById("message4").innerHTML = " ";   
        }
    }
    function validate(){  
var num=document.myform.phone.value;  
var pin = document.myform.zip.value;
if (isNaN(num)){  
  document.getElementById("numloc").innerHTML="Enter Numeric value only";  
  return false;  
}else{  
  document.getElementById("numloc").innerHTML=" ";
  return true;  
  }  
}  
function pinvalid(){
  var pin = document.myform.zip.value;
  if (isNaN(pin)){  
  document.getElementById("numloc1").innerHTML="Enter Numeric value only";  
  return false;  
}else{  
  document.getElementById("numloc1").innerHTML=" ";
  return true;  
  } 
}
      </script>
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}
input[type=email] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}
input[type=number] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
</head>
<body>

<h2><center>Checkout</center></h2>
<p>Please fill the required Details. </p>
<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="checkout_action.php" method="post" name="myform">
      
        <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="field2" onblur="checkField1();" name="firstname" placeholder="" required><br> <span id = 'message2'></span><br>
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="email" id="email" name="email" placeholder="" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="" required>
            <label for="phone">Phone</label>
            <input type="text" name="phone" placeholder="" id="phone" onblur="validate()"; required><span id="numloc"></span><br>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" name="city" placeholder="" id="field3" onblur="checkField2();" required><br> <span id = 'message3'></span><br>
           

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                <input type="text" id="field21" name="state" placeholder="" onblur="checkField21();" required><br> <span id = 'message31'></span><br>
              </div>
              <div class="col-50">
                <label for="zip">Zip</label>
                <input type="text" id="zip" name="zip" placeholder="" onblur="pinvalid()"; required><br> <span id = 'numloc1'></span><br>
              </div>
            </div>
          </div>
        </div>
        <h3>Grand Total: Rs. <?php echo $sum ?></h3>
        <input type="text" value="<?php echo $sum ?>" name = "sum" style='display: none;'/>
        <input type="submit" name="submit" value="Continue to checkout" class="btn">
      </form>
    </div>
  </div>
  
  </div>
</div>

</body>
</html>
