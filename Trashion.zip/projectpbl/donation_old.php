<html>
<head><title>Donate</title>
<style>
* {box-sizing: border-box}

/* Add padding to containers */
.container {
  padding: 16px;
  width:500px;
  height:100%;
  align:center;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit/register button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity:1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>
<form  method="POST" action="donation_data.php" enctype="multipart/form-data">
  <div class="container">
    <h1>Donation</h1>
    <hr>

<label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" id="name" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required>

    <label for="address"><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address" id="address" required>

    <label for="phone_no"><b>Phone</b></label>
    <input type="text" placeholder="Enter Phone_no" name="phone" id="phone" required>
	
	<label for="Type of Product to Donate"><b>Type of Product to Donate</b></label>
    <input type="text" placeholder="Enter Details" name="type" id="type" required>
    <label for="details"><b>Details of Product to Donate</b></label>
    <input type="text" placeholder="Enter Details" name="details" id="details" required>
   Select image to upload:
  <input type="file" name="file" id="file">

	
    <hr>
    <br>

    <button type="submit" class="registerbtn" name="submit">Register</button><br>
  </div>
  

  <div class="container signin">
  </div>
</form>
</body>
</html>


