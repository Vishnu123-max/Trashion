<html>
<head>
	<meta charset="UTF-8">
	<title>Trashion</title>
	<link href="style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link href='https://fonts.googleapis.com/css?family=Assistant' rel='stylesheet'>
	




</head>
<body>
<a href = "trashiondashboard.html"><img align="left" src="images1/trashionlogo.jpg" alt="Health logo" width="10%" height="15%"></a>
    <h1 style="font-family:georgia">CART</h1>
    <br/>

<?php
session_start();
$uid = $_SESSION["id"];
$con = mysqli_connect("localhost","root","","projectpbl");
if (mysqli_connect_errno()){
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    die();
    }

    
    echo '<center><table class="w3-table-all w3-large" style="width:70%;">  
    <tr class="w3-green">
        <th class="w3-center" style="width:200px">Product_id</th> 
        <th class="w3-center">Name</th> 
        <th class="w3-center">Cost</th> 
        <th class="w3-center"> </th>
    </tr>';
  
$sql2 = "SELECT * from orders where User_id = '$uid'";
$sum = 0;
if ($result1 = $con->query($sql2)) {
    while ($row = $result1->fetch_assoc()) {
        $field1name = $row["Product_id"];
        $field2name = $row["Name"];
        $field3name = $row["Cost"];
        $field4name = $row["Order_id"];
        $sum = $sum + $field3name;
        echo '<tr>  
            <td>'.$field1name.'</td>  
            <td>'.$field2name.'</td>
            <td>'.$field3name.'</td>
            <td>
            <form action="delete.php" method="post">
            <input type="hidden" value="'.$field4name.'" name = "Order_id">
            <input class="w3-button w3-green" type="submit" value="Delete Product">
            </form>
            </td>
            </tr>';
        
    }
    //$result1->free();
} 
echo '<tr>
        <td>Total</td>
        <td>'.$sum.'</td>
</tr>';
echo '<br><a href = "trashiondashboard.html"><input class="w3-button w3-green" type="submit" value="Continue Shopping"></a><br><br>';

?>
</body>
</html>