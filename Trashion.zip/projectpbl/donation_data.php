<?php

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'projectpbl');

if(isset($_POST['submit'])){
     $name = $_POST['name'];
     $email = $_POST['email'];
	 $address = $_POST['address'];
     $phone = $_POST['phone'];
     $type = $_POST['type'];
     $details = $_POST['details'];

     $q = "INSERT INTO `register`(`name`,`email`,`address`,`phone`, `type`,`details`) VALUES ('$name','$email', '$address','$phone','$type','$details')";

     $query = mysqli_query($con, $q);
     $name       = $_FILES['file']['name'];  
        $temp_name  = $_FILES['file']['tmp_name'];  
        if(isset($name) and !empty($name)){
            $location = 'uploads/';      
            if(move_uploaded_file($temp_name, $location.$name)){
                echo '<script>alert("Donation Successfully Recorded")</script>';    
            }
        } else {
            echo '<script>alert("Please select a file to upload your donation record")</script>';
        }
    }
    ?>
    <script type="text/javascript">window.location = "donation.php"; </script>   
<?php>