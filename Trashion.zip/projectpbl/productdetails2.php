<html>
<head>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Trashion</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link href="style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="style1.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
.float-container {
    padding-right: 40px;
    padding-left: 80px;
    
}
.float-container1 {
    padding-right: 30px;
    padding-left: 30px;
    
}

.float-child {
    width: 45%;
    height: 70%;
    float: left;
    padding: 20px;
    
}
  .hide { position:absolute; top:-1px; left:-1px; width:1px; height:1px; }


</style>
</head>
<?php
session_start();
//connecting to database 
$username = "root"; 
$password = ""; 
$database = "projectpbl"; 
$mysqli = new mysqli("localhost", $username, $password, $database);

//initialize global variables
$field1name = "Name";
$field2name = 10;
$field3name = 10;

//$id = $_POST['Product_id'];
$id = ''; 
if( isset( $_POST["Product_id"])) {
    $id = $_POST["Product_id"]; 
} 
$sql = "SELECT * FROM product where Product_id = '$id'";

$Product_id = $id;
$directory = "./images/";
if ($result = $mysqli->query($sql)) {
    while($row = $result->fetch_assoc()){ 
        $field1name = $row["Name"];
        $field2name = $row["Cost"];
        $field3name = $row["Units"];
        $field4name = $row["Description"];
        $tag1 = $row['tag1'];
        // echo "$tag1";
        $tag2 = $row['tag2'];
        $tag3 = $row['tag3'];
        $tag4 = $row['tag4'];
    //$result->free();
}
}
?>
<body >
    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.html"><img src="images/logo.png" class="logo" alt=""></a>
                </div>
                <!-- End Header Navigation -->

                

                <!-- Start Atribute Navigation -->
                
                <!-- End Atribute Navigation -->
				</nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
    <div class="top-search">
        <div class="container">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
            </div>
        </div>
    </div>
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box" style="background-image:url(https://fairware.com/wp/wp-content/uploads/2015/09/padfolios-800x340.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Shop Detail</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="trashiondashboard.html">Shop</a></li>
                        <li class="breadcrumb-item active">Shop Detail </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    


<div class="float-container">
  <div class= "float-child">
    <center><?php
      echo '<img  src = "'.$directory.$Product_id.'.jpg" class="d-block h-100">';
      ?></center>
    
  </div>
  
  <div class= "float-child">
  <div class="single-product-details">
                <h2><?php echo $field1name; ?></h2>
                <p class ='price'> Price<br>Rs. <?php echo $field2name; ?></p>
                <p class="available-stock"><span> More than 20 available / <a href="#">8 sold </a></span><p>
                <h4>Short Description:</h4>
                <?php echo $field4name; ?>
              
            <div class="price-box-bar" style = "5px solid black">
                <div class="cart-and-bay-btn">
                <form action= "mycart.php" method= "post">
                <ul>
							<li>
								<div class="form-group quantity-box">
									<label class="control-label">Quantity</label>
									<input class="form-control" value="1" min="1" max="10" type="number" name = "qty"/>
								</div>
							</li>
						</ul>
                    <input type="text" value="<?php echo $Product_id ?>" name = "Product_id" style='display: none;'/>
                    <input type='submit' class="btn hvr-hover" name = "submit" value='Add to Cart' width="200px" padding="10px 20px">
                </form>
                </div></div>
  </div>  
  </div>

<br><br><br><br>><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <!-- Recommendation box -->
<div class="float-container"> 

<br><hr>
            <h4 align="center">Recommended Products</h4>
        <div id="recommendation_div" class="">

          <table id="recommendation_table" style="border: 2px solid black">
            <tr>

              <!--  or tag3 = '$tag3' or tag4 = '$tag4' -->
              <?php
              $space = '';
                $query_recommend = "select Product_id, Name, cost, Description from product WHERE tag1 = '$tag1' or tag2 = '$tag2' or tag3 = '$tag3' or tag4 = '$tag4' and tag3 <> '$space' and tag4 <> '$space'";
                $recommend_limit = 0;
                if ($result = $mysqli->query($query_recommend)) {
                    while($row = $result->fetch_assoc() and $recommend_limit < 5){
                      if ($Product_id == $row["Product_id"]) {
                        continue;
                      }
                      $recommend_limit += 1;

                      // echo "<pre>";
                      // print_r($row);
                      echo "<td style='width: 20%;' align='center'>";
                        echo '<img  src = "'.$directory.$row["Product_id"].'.jpg" height="200px" width="200px"><hr>';
                        echo $row["Name"]."<br>";
                        echo "<div id='recommendation_rs'>Rs. ".$row["cost"]."</div><br><hr>";
                       echo "<form action= 'productdetails2.php' method= 'post'>
                       <input type='hidden' value= ".$row['Product_id']." name = 'Product_id'>
                       <input type='submit' value='View Product Details' name = 'submit' class='btn hvr-hover'>
                       </form>";
                        echo "<td>";
                    }
                }
                ?>
              </tr>
          </table>
</div>
<br>
<br>
<br>
<br>
<!-- Start Footer  -->
<footer>
        <div class="footer-main">
            <div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<h3>Business Time</h3>
							<ul class="list-time">
								<li>Monday - Friday: 08.00am to 05.00pm</li> <li>Saturday: 10.00am to 08.00pm</li> <li>Sunday: <span>Closed</span></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<!-- <h3>Newsletter</h3>
							<form class="newsletter-box">
								<div class="form-group">
									<input class="" type="email" name="Email" placeholder="Email Address*" />
									<i class="fa fa-envelope"></i>
								</div>
								<button class="btn hvr-hover" type="submit">Submit</button>
							</form> -->
						</div>
					</div>
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<h3>Social Media</h3>
							<p>Follow us on!</p>
							<ul>
                                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
						</div>
					</div>
				</div>
				<hr>
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-widget">
                            <h4>About Trashion</h4>
                            <p>A platform for recycled materials and waste collection.</p> 
							<p>Led by people who care for nature for people who care for nature. </p> 							
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link">
                            <!-- <h4>Information</h4>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Customer Service</a></li>
                                <li><a href="#">Our Sitemap</a></li>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Delivery Information</a></li>
                            </ul> -->
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link-contact">
                            <h4>Contact Us</h4>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Address: Thakur COllege of Engineering and Technology <br>Thakur Village, Kandivali(East),<br>Mumbai-400101. </p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Phone: <a href="tel:+1-888705770">888 705 770</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:contactinfo@gmail.com">contactinfo@gmail.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer  -->

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
    </body>

</html>