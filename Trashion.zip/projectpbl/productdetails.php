<html>
<head>
<title>Product Details</title>
<meta charset="UTF-8">
	<title>Online Health Shopping Portal</title>
	<link href="style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link href='https://fonts.googleapis.com/css?family=Assistant' rel='stylesheet'>
</head>

<body>
<?php
//connecting to database 
$username = "root"; 
$password = ""; 
$database = "health1"; 
$mysqli = new mysqli("localhost", $username, $password, $database);


//$id = $_POST['Product_id'];
$id = ''; 
if( isset( $_POST["Product_id"])) {
    $id = $_POST["Product_id"]; 
} 
$sql = "SELECT * FROM product where Product_id = '$id'";
if ($result = $mysqli->query($sql)) {
    $row = $result->fetch_assoc();
        $field1name = $row["Name"];
        $field2name = $row["Cost"];
        $field3name = $row["Units"];
        $field4name = $row["Description"];
        $field5name = $row["Category"];
    //$result->free();
}
echo '<center><table class="w3-table-all w3-large" style="width:70%;">  
      <tr class="w3-green">
          <th> Name </th> 
          <th class="w3-center" style="width:200px"> Cost </th> 
          <th class="w3-center"> Units </th>
          <th class="w3-center"> Description </th>
          <th class="w3-center"> Category </th> 
          <th class="w3-center"> Photo </th> 
      </tr>';
echo '<tr> 
            <td><b>'.$field1name.'</b></td> 
            <td class="w3-center">'.$field2name.'</td>  
            <td class="w3-center">'.$field3name.'</td>
            <td class="w3-center">'.$field4name.'</td>
            <td class="w3-center">'.$field5name.'</td>
            <td class="w3-center"><img src = "./images/'.$row['Product_id'].'.jpg" alt="Photo of '.$row['Name'].'" width =350 height= 350></td> 
            </tr>';

?>
</body>
</html>