<html>
<head><title>Donate</title>
<script>

    function checkField1()
    {
        var a= /^[A-Za-z]+$/;
      var field = document.getElementById("field2").value;
        if (field.match(a))
      {
        document.getElementById("message2").innerHTML = " ";
      }
      else
            document.getElementById("message2").innerHTML = "Input Empty or numbers or special characters used.";
        
    }
    function checkField2(){
        var a= /^[A-Za-z]+$/;
        var lname = document.getElementById("field3").value;
        if (lname.match(a))
      {
        document.getElementById("message3").innerHTML = " ";
      }
      else
            document.getElementById("message3").innerHTML = "Input Empty or numbers or special characters used.";
    }
    function checkField3()
    {
      var field = document.getElementById("password").value;
      var fieldpsw = document.getElementById("password").value.replace(/^\s+/, '').replace(/\s+$/, '');
      var pattern= /^[^\s]+(\s+[^\s]+)*$/;
      if (fieldpsw === ''){
        document.getElementById("message5").innerHTML = "Password cannot be only whitespaces";
      } 
      else if(field.match(pattern)) {
        document.getElementById("message5").innerHTML = " ";
        if (field.length < 5)
      {
        document.getElementById("message5").innerHTML = "Too short!";
      }
      else
        document.getElementById("message5").innerHTML = "That's perfectly splendid!";
    }
    else{
      document.getElementById("message5").innerHTML = "Password cannot begin or end with a whitespace";
    }
        }
      
    function confirmpassword(){
        pass1= document.getElementById("password").value;
        pass2= document.getElementById("password_confirm").value;
        if(pass1 != pass2)
        {
            document.getElementById("message4").innerHTML = "Password does not match";
        }
        else{
          document.getElementById("message4").innerHTML = " ";   
        }
    }
    function validate(){  
var num=document.myform.phone.value;  
if (isNaN(num)){  
  document.getElementById("numloc").innerHTML="Enter Numeric value only";  
  return false;  
}else{  
  document.getElementById("numloc").innerHTML=" ";
  return true;  
  }  
}  
      </script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>MyCart</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
      input[type=text], input[type=password], input[type=email] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
input[type=text]:focus, input[type=password]:focus,input[type=email]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit/register button */
.registerbtn {
  background-color: #b0b435;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity:1;
}
    </style>
</head>

<body>
 <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.html"><img src="images/logo.png" class="logo" alt=""></a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="trashionindex.html">Home</a></li>
                        
                        <li class="dropdown active">
                            <a href="#" class="nav-link dropdown-toggle arrow" data-toggle="dropdown">SHOP</a>
                            <ul class="dropdown-menu" style=" font-weight: bold; font-size:120%;">
								<li><a href="trashionindex.html">Sidebar Shop</a></li>
								<li><a href="trashionindex.html">Shop Detail</a></li>
                <li><a href="mycart.php">Cart</a></li>
                                
                                <li><a href="stationary.php">Stationary</a></li>
								<li><a href="electronics.php">Electronics</a></li>
                                <li><a href="kitchen.php">Kitchen</a></li>
                                <li><a href="accessories.php">Accessories</a></li>
                                <li><a href="decor.php">Decor</a></li>
                            </ul>
                        </li>
                        
                        <li class="nav-item"><a class="nav-link" href="contact-us.html">Contact Us</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <!-- <ul>
                        <li class="search"><a href="#"><i class="fa fa-search"></i></a></li>
                        <li class="side-menu"><a href="#">
						<i class="fa fa-shopping-bag"></i> -->
                            <!--<span class="badge">3</span>-->
                            
					</a></li>
                    </ul>
                </div>
				</div>
				</nav>
        <!-- End Navigation -->
    </header>
	<!-- End Main Top -->

    <!-- Start Top Search -->
    <div class="top-search">
        <div class="container">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
            </div>
        </div>
    </div>
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box" style="background-image: url(https://c8.alamy.com/comp/JB5PCJ/strip-ethnic-seamless-pattern-design-JB5PCJ.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Cart</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="trashionindex.html">Shop</a></li>
                        <li class="breadcrumb-item active">Donation</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->


<form  method="POST" action="donation_data.php" enctype="multipart/form-data" name="myform">

        <div class="container" style="align:center;  padding: 16px;
  width:500px;">
                <div class="col-lg-12">
                    <div class="table-main table-responsive">
                        <table class="table">
                            <thead >
                            <p  style="color:#b0b435; font-weight: bold; font-size:150%;">DONATION</p>
                            </thead>
                            <tbody>
    <hr>

<label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" id="field2" onblur="checkField1();" required><br> <span id = 'message2'></span><br>
<br>
    <label for="email"><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="email" id="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>

    <label for="address"><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address" id="address" required>

    <label for="phone_no"><b>Phone</b></label>
    <input type="text" placeholder="Enter Phone" name="phone" id="phone" onblur="validate()"; required><span id="numloc"></span><br>
	
	<label for="Type of Product to Donate"><b>Type of Product to Donate</b></label>
    <input type="text" placeholder="Enter Details" name="type" id="type" required>
    <label for="details"><b>Details of Product to Donate</b></label>
    <input type="text" placeholder="Enter Details" name="details" id="details" required>
   Select image to upload:
  <input type="file" name="file" id="file">

	
    <hr>
    <br>

    <button type="submit" class="registerbtn" name="submit">Register</button><br>
  </div>
  

  <div class="container signin">
  </div>
</form>
</tbody>
</table>
</div>
</div></div></div>
	<!-- Start Footer  -->
  <footer>
        <div class="footer-main">
            <div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<h3>Business Time</h3>
							<ul class="list-time">
								<li>Monday - Friday: 08.00am to 05.00pm</li> <li>Saturday: 10.00am to 08.00pm</li> <li>Sunday: <span>Closed</span></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<!-- <h3>Newsletter</h3>
							<form class="newsletter-box">
								<div class="form-group">
									<input class="" type="email" name="Email" placeholder="Email Address*" />
									<i class="fa fa-envelope"></i>
								</div>
								<button class="btn hvr-hover" type="submit">Submit</button>
							</form> -->
						</div>
					</div>
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<h3>Social Media</h3>
							<p>Follow us on!</p>
							<ul>
                                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
						</div>
					</div>
				</div>
				<hr>
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-widget">
                            <h4>About Trashion</h4>
                            <p>A platform for recycled materials and waste collection.</p> 
							<p>Led by people who care for nature for people who care for nature. </p> 							
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link">
                            <!-- <h4>Information</h4>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Customer Service</a></li>
                                <li><a href="#">Our Sitemap</a></li>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Delivery Information</a></li>
                            </ul> -->
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link-contact">
                            <h4>Contact Us</h4>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Address: Thakur COllege of Engineering and Technology <br>Thakur Village, Kandivali(East),<br>Mumbai-400101. </p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Phone: <a href="tel:+1-888705770">888 705 770</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:contactinfo@gmail.com">contactinfo@gmail.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer  -->
	<!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
    </body>


</html>


