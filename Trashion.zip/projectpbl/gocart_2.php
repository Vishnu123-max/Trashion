<?php
session_start();
$uid = $_SESSION["id"];
$con = mysqli_connect("localhost","root","","projectpbl");
if (mysqli_connect_errno()){
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    die();
    }

    
    echo '<center><table class="w3-table-all w3-large" style="width:70%;">  
    <tr class="w3-green">
        <th class="w3-center" style="width:200px">Product_id</th> 
        <th class="w3-center">Name</th> 
        <th class="w3-center">Cost</th> 
    </tr>';
  
$sql2 = "SELECT * from orders where User_id = '$uid'";
$sum = 0;
if ($result1 = $con->query($sql2)) {
    while ($row = $result1->fetch_assoc()) {
        $field1name = $row["Product_id"];
        $field2name = $row["Name"];
        $field3name = $row["Cost"];
        $field4name = $row["Order_id"];
        $sum = $sum + $field3name;
        echo '<tr>  
            <td>'.$field1name.'</td>  
            <td>'.$field2name.'</td>
            <td>'.$field3name.'</td>
            <td>
            <form action="delete.php" method="post">
            <input type="hidden" value="'.$field4name.'" name = "Order_id">
            <input class="w3-button w3-green" type="submit" value="Delete Product">
            </form>
            </td>
            </tr>';
        
    }
    //$result1->free();
} 
echo '<tr>
        <td>Total</td>
        <td>'.$sum.'</td>
</tr>';
echo '<a href = "dashboard.html">Continue Shopping</a>';

?>
