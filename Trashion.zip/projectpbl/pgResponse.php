<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

// following files need to be included
require_once("config_paytm.php");
require_once("encdec_paytm.php");

$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";

$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg

//Verify all parameters received from Paytm pg to your application. Like MID received from paytm pg is same as your application�s MID, TXN_AMOUNT and ORDER_ID are same as what was sent by you to Paytm PG for initiating transaction etc.
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); //will return TRUE or FALSE string.


if($isValidChecksum == "TRUE") {
	//echo "<b>Checksum matched and following are the transaction details:</b>" . "<br/>";
	if ($_POST["STATUS"] == "TXN_SUCCESS") {
		echo "<h3><b><h3><center>Transaction Successful</h3></b>" . "</h3><br/>";
		//Process your transaction here as success transaction.
		//Verify amount & order id received from Payment gateway with your application's order id and amount.
	}
	else {
		echo "<b><h3><center>Transaction Failed<center></h3></b>";
	}

}
else {
	echo "<b>Checksum mismatched.</b>";
	//Process transaction as suspicious.
}

?>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
	.styled-table {
    border-collapse: collapse;
    font-size: 0.9em;
    font-family: sans-serif;
    width: 800px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    margin-left: auto;
    margin-right: auto;
	table-layout: fixed;
}
.styled-table th{
    background-color: #009879;
    color: #ffffff;
    text-align: center;
}
.styled-table td {
    padding: 12px 15px;
    width: 30%;
	word-wrap: break-word;
	white-space: -o-pre-wrap; 
    word-wrap: break-word;
    white-space: pre-wrap; 
    white-space: -moz-pre-wrap; 
    white-space: -pre-wrap; 
}
.styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
    text-align: center;
}

.styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
}

.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
}
.styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
	word-wrap: break-word;
}
</style>
</head>
<body>
	<script>
		function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
		</script>
<h3><center>Payment Details</center></h3>
<div id="printableArea">
	<?php
	if (isset($_POST) && count($_POST)>0 )
	{ 
		echo "<table border='2' align='center' class='styled-table'>";
		echo "<tbody>";
		foreach($_POST as $paramName => $paramValue) {
			if($paramName=="CHECKSUMHASH" || $paramName=="MID" || $paramName=="TXNID" || $paramName=="RESPCODE" ){
				continue;
			}	
			else{
			echo "<tr><th>". $paramName . "</th><td>" . $paramValue."</td></tr>";
			}
		}
		echo "</tbody>";
		echo "</table>";
	}
	
	?>

</div>
<div class="container" align="center">
	<br>
  <a href="trashiondashboard.html" class="btn btn-success">Continue Shopping</a>
  <button type="button" class="btn btn-success" onclick="printDiv('printableArea')">Print the reciept</button>    
  <br>
  <br>
</div>

</body>
</html>
