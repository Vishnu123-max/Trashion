<?php
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'projectpbl');
$query="select * from register";
$result= mysqli_query($con,$query);
?>

<!doctype html>
 <html>
      <title>
	       <head> Fetch Data From Database</head>
		</title>
<body>
  <table align="center" border="1px" style="width:600px; line-height:50px;">
         <tr>
		    <th colspan="4"><h2>Details</h2></th>
          </tr>
         <t>
             <th> Name </th>
			 <th> Email address </th>
			 <th> Password </th>
			 <th> Address</th>
			 <th> Phone</th>
		 </t>
	  <?php
	     while($rows = mysqli_fetch_array($result))
		 {
		?>
		 <tr>
		   <td><?php echo $rows['name']; ?> </td>
		   <td><?php echo $rows['email']; ?> </td>
		   <td><?php echo $rows['psw']; ?> </td>
		   <td><?php echo $rows['address']; ?> </td>
		   <td><?php echo $rows['phone']; ?> </td>
		  </tr>
		  
		<?php
		 }
	    ?>
		 
		 </table>
		 </body>
		 </html>
		 
			        	        
			    
  				   