<?php
unset($_SESSION["id"]);
unset($_SESSION["name"]);
unset($_SESSION["valid"]);
session_destroy();
header("location:trashionindex.html");
?>