<html>
<head>
	<meta charset="UTF-8">
	<title>Online Health Shopping Portal</title>
	<link href="style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link href='https://fonts.googleapis.com/css?family=Assistant' rel='stylesheet'>
	




</head>
<body>
<a href = "trashiondashboard.html"><img align="left" src="images1/trashionlogo.jpg" alt="Health logo" width="10%" height="15%"></a>
    <h1 style="font-family:georgia">Electronics</h1>
    <br/>
<?php 
$username = "root"; 
$password = ""; 
$database = "projectpbl"; 
$mysqli = new mysqli("localhost", $username, $password, $database); 
$query = "SELECT * FROM product where category = 'Electronics'";


echo '<center><table class="w3-table-all w3-large" style="width:70%;">  
      <tr class="w3-green">
          <th> Name </th> 
          <th class="w3-center" style="width:200px"> Cost </th> 
          <th class="w3-center"> Photo </th> 
          <th class="w3-center">  </th> 
      </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["Name"];
        $field3name = $row["Cost"];
        $field2name = $row["Product_id"];
        echo '<tr> 
            <td><b>'.$field1name.'</b></td> 
            <td class="w3-center">'.$field3name.'</td>  
            <td class="w3-center"><img src = "./images/'.$row['Product_id'].'.jpg" alt="Photo of '.$row['Name'].'" width =350 height= 350></td> 
            <td><form action="productdetails2.php" method="post">
            <input type="hidden" value="'.$field2name.'" name = "Product_id">
            <input class="w3-button w3-green" type="submit" value="View Product Details">
            </form></td>
            </tr>';
    }
    $result->free();
} 
?>
</body>
</html>