<?php

session_start();
$con = mysqli_connect("localhost","root","","projectpbl");
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: " . mysqli_connect_error();
die();
}

$id = '';
if( isset( $_POST["submit"])) {
  $id = $_POST["Order_id"]; 
}
else{
    //echo "No";
}

$uid = $_SESSION["id"];
$sql = "DELETE FROM orders where Order_id = '$id'";
if ($con->query($sql) === TRUE) {
    echo "<script>alert('Record Deleted Successfully')</script>";
  } else {
    echo "Error deleting record: " . $con->error;
  }
header("location:mycart.php");
?>
