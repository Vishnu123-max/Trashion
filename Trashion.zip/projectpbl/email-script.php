<?php
$con = mysqli_connect("localhost","root","","projectpbl");
if (mysqli_connect_errno()){
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  die();
  }
if (isset($_POST['sendMailBtn'])) {
    $fromEmail = $_POST['fromEmail'];
    //$toEmail = $_POST['toEmail'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];;
    $result = mysqli_query($con,"INSERT INTO email(user,subject,message) VALUES('$fromEmail','$subject','$message')");
      if($result){
        echo '<script>alert("Email sent successfully !")</script>';
        }else{
          echo "The record was not inserted successfully---->" . mysqli_error($con);
        }
      }
    echo '<script>window.location.href="trashionindex.html";</script>';

    ?>